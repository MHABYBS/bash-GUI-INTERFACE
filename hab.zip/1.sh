#!/bin/bash

yad --form --width=250 --text="Choose a command:" \
--field="Lsblk":fbtn "./1ls.sh" \
--field="Df":fbtn "./1df.sh" \
--button=gtk-cancel:1
