#!/bin/bash
gnuplot -p plotlsblk.sh
