#!/bin/bash

projet(){
#lblk: gnuplot -e "plot "test.dat" using 2:4 with lines"
#ldf: gnuplot -e "plot "test.dat" using 4:5 with lines"
for i in $@
do
	if [[ $i == "-lblk" ]]; then lsblk
	lsblk -b > test.dat
	result="-lblk"
	elif [[ $i == "-h" || $i == "-help" && $result == "-lblk" ]]; then lsblk -help
	elif [[ $i == "-gnuplot" || $i == "-plot" && $result == "-lblk" ]]; then
	gnuplot plotlsblk.sh
	elif [[ $i == "-ldf" ]]; then df
	df > test.dat
	result="-ldf"
	elif [[ $i == "-h" || $i == "-help" && $result == "-ldf" ]]; then df -help
	elif [[ $i == "-gnuplot" || $i == "-plot" && $result == "-ldf" ]]; then
	gnuplot plotldf.sh
        elif [[ $i == "-g" ]]; then ./1.sh
	fi
done
}
