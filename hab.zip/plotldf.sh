set xlabel "pourcentage d'utilisation"
set ylabel "disponibilité"
plot "test.dat" using 4:5 with lines

