#!/bin/bash
lsblk -help
