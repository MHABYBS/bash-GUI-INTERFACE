#!/bin/bash

gnuplot -p plotldf.sh
