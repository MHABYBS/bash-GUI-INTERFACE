#!/bin/bash
lsblk
lsblk -b > test.dat
yad --form --width=250 --text="choose an option:" \
--field="Help":fbtn "./lsh.sh" \
--field="Gnuplot":fbtn "./lsg.sh" \
--button=gtk-cancel:1






