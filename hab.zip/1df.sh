#!/bin/bash
df
df > test.dat
yad --form --width=250 --text="choose an option:" \
--field="Help":fbtn "./dh.sh" \
--field="Gnuplot":fbtn "./dg.sh" \
--button=gtk-cancel:1
