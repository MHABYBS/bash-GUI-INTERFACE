#!/bin/bash
df --help
